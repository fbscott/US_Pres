var USPresidents = USPresidents || new Marionette.Application();

USPresidents.addRegions({

    mainRegion : '#mainRegion'

});
