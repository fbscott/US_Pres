USPresidents.Controller = {

    deleteView : function() {

    }

};
